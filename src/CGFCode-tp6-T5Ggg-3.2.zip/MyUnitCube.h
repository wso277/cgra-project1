#ifndef MYCUBE_H
#define MYCUBE_H

#include "CGFobject.h"
class myUnitCube : public CGFobject
{
public:

	void draw();
};

#endif