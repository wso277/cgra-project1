#ifndef MYTABLE_H
#define MYTABLE_H

#include "MyUnitCube.h"

class myTable  : public CGFobject
{
	myUnitCube cube;
public:
	void draw();
};
#endif
